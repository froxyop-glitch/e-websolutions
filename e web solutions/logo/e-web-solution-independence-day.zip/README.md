# E Web Solution — Independence Day Special

A single-page, publish-ready site for the Independence Day Graphics Design Competition.

## What's inside

```
index.html            the site (self-contained HTML/CSS/JS)
favicon.svg            vector app icon
favicon-32.png          browser tab icon
apple-touch-icon.png     180×180 iOS home-screen icon
icon-192.png / icon-512.png   Android / PWA icons
site.webmanifest        home-screen metadata (iOS/Android "Add to Home Screen")
robots.txt              search engine crawl permissions
```

## Deploy

Upload the whole folder to any static host — no build step required.

- **Vercel / Netlify:** drag the folder into the dashboard, or `vercel deploy` / `netlify deploy` from inside it.
- **GitHub Pages:** push the folder to a repo and enable Pages on the `main` branch.
- **Any web server:** copy the folder to your web root — `index.html` is the entry point.

## Before you go live

- Update the `Submit Now` link in `index.html` (search for `portal.html`) if your submission portal URL changes.
- Swap `og:image` in `<head>` for a full-size social preview image if you want a richer link preview (currently uses the 512px app icon).

## Device support

Tested against iOS Safari, iPadOS Safari, Android Chrome, and desktop breakpoints from 360px up to ultra-wide (1440px+). Respects `prefers-reduced-motion`, uses safe-area insets for notch devices, and all tap targets meet the 44px minimum.
